
<?php 
if (isset($_POST['id']) && !empty($_POST['id'])) {
    
 }else{
    header("Location: tienda.php");
    exit;
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mundo | Perfil Producto</title>
    <!-- menu  -->
    <link rel="stylesheet" href="css/menu.css">
    <script src="js/jquery.js"></script>
    <script src="js/cargado.js"></script>
    <script src="https://kit.fontawesome.com/fd543783d4.js" crossorigin="anonymous"></script>
    <!-- menu  --> 

</head>
<body>
<?php
    include 'controladores/metodosPrincipales.php';
    include 'controladores/tienda.php'; 
    DesplegarMenu();
   // filtrado();
    
?>

<?php
    include 'controladores/perfilProducto.php'; 
    perfil();
?>

</body>
</html>