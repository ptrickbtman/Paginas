<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mundo purpura</title>
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/index.css">
    <script src="js/jquery.js"></script>
    <script src="js/cargado.js"></script>
    <script src="https://kit.fontawesome.com/fd543783d4.js" crossorigin="anonymous"></script>
</head>
<body>
<?php
    include 'controladores/metodosPrincipales.php'; 
    DesplegarMenu()
?>

<div class="portada">
    <div class="contenPortada">
        <p class="tituloPortada"> Mundo Purpura</p>
        <p class="subPortada">Piezas únicas</p>
        <i class="fas fa-chevron-down"></i>
    </div>
    
</div>
    
</body>
</html>