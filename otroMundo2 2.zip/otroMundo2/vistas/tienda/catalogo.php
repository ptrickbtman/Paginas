
<div class="contenedor">
    <div class="contentFoto">
        <img class="imgCatalogo2" src="<?php echo $productos[$i][7];?> " alt="img no encontrada">
        <div class="infoProducto">
            <form class="form-producto <?php echo 'form'.(string)$productos[$i][0];?> ">
                
                <input type="hidden" name="id" value="<?php echo $productos[$i][0]; ?>">
                <input type="hidden" name="titProducto" value="<?php echo $productos[$i][3] ?>">
                <input type="hidden" name="desProducto" value="<?php echo $productos[$i][4]?>">
                <input type="hidden" name="precioProducto" value="<?php echo $productos[$i][5]?>">
                <input type="hidden" name="url" value="<?php echo $productos[$i][7];?> ">
                <input type="button" class="btnVerMas" value="Ver producto" onclick="cargarDatos(<?php echo $productos[$i][0]; ?>)">
                
            </form>
        </div>
    </div>
</div>



