<table border="1">
	<tr>
		<th colspan="2">Lista de <?php echo $X; ?> registrados</th>
	</tr>
	<tr>
		<td><?php echo $x; ?>:</td>
		<td>Opciones:</td>
	</tr>
	<?php  
	if ($X=="colores") {
		$atributos = array('ID_COL','NOM_COL');
		$REPAG = "btn1";
	}elseif($X=="tipos"){
		$atributos = array('ID_TIP','NOM_TIP');
		$REPAG = "btn2";
	}


	//-----Datos paginacion--------

	$pagAct=1;// Pagina actual
	if(isset($_GET['pag']) && !empty($_GET['pag'])){
		$pagAct = $_GET['pag'];
	}
	$registroIni=0;// Registro inicial
	$intervalo=10;// intervalo de registros
	if ($pagAct>1) {
		$registroIni = $intervalo*($pagAct-1);
	}

	//-----------------------------

	$colTip = SelectLimit($X,$atributos,$registroIni,$intervalo);

	if (count($colTip)>0 and !empty($colTip[0][0])) {
		for ($i = 0  ; $i < count($colTip) ; $i++){
			?>
			<tr>
				<td><?php echo $colTip[$i][1]; ?></td>
				<td>
					<form action="actualizarColTip.php" method="post">
						<input type="hidden" name="colTip" value="<?php echo $X; ?>">
						<input type="hidden" name="colTip2" value="<?php echo $x; ?>">
						<input type="hidden" name="idList" value="<?php echo $colTip[$i][0]; ?>">
						<input type="hidden" name="nomList" value="<?php echo $colTip[$i][1]; ?>">
						<input type="submit" name="btnList" value="Editar">
						<input type="submit" name="btnList" value="Eliminar">
					</form>
				</td>
			</tr>
			<?php
		}
	}
	?>
</table>
<?php  
$canti = SelectCount($X,$atributos[0]);
paginacionColTip(maxPaginas($canti,$intervalo),'ingresoColTip.php',$REPAG);
?>