<?php 
if ($_POST['colTip']=="colores") {
	$p = "color: ";
}else{
	$p = "tipo: ";
}
?>
<table border="1">
	<tr>
		<th colspan="2">Eliminar <?php echo ($p.$_POST['nomList']); ?>?</th>
	</tr>
	<tr>
		<td colspan="2">
			<input type="hidden" name="colTip" value="<?php echo $_POST['colTip']; ?>">
			<input type="hidden" name="idList" value="<?php echo $_POST['idList']; ?>">
			<input type="hidden" name="nomList" value="<?php echo $_POST['nomList']; ?>">
			<input type="submit" name="btnColtip" value="Eliminar">
			<input type="button" value="Cancelar" onclick="history.back();">
		</td>
	</tr>
</table>