<?php  
$atributos = array('ID_COL','NOM_COL');
$col = Select('colores',$atributos);
$atributos = array('ID_TIP','NOM_TIP');
$tip = Select('tipos',$atributos);
?>
<table border="1">
	<tr>
		<th colspan="3">Ingreso de productos</th>
	</tr>
	<tr>
		<td>
			<label for="nom">Titulo:</label>
		</td>
		<td>
			<!-- required="true" -->
			<input type="text" name="nom" maxlength="50" >
		</td>
		<td rowspan="7" class="tdFotos">
			<div class="divFiles">
				<?php  
				for ($i=0; $i <10 ; $i++) { 
					?>
					<div class="divFile">
						<div class="contFotos">
							<img src="img/default.png" class="visFotos"  id="vis<?php echo $i; ?>">
						</div>
						<input type="file" name="fotos[]" id="fi<?php echo $i; ?>"><input type="radio" name="fotSel" id="rdSel<?php echo $i ?>">
					</div>
					<?php
				}
				?>
			</div>
		</td>
	</tr>
	<tr>
		<td>
			<label for="cod">Codigo:</label>
		</td>
		<td>
			<!-- required="true" -->
			<input type="text" name="cod" maxlength="10" >
		</td>
		
	</tr>
	<tr>
		<td>
			<label for="col">Color producto:</label>
		</td>
		<td>
			<!-- required="true" -->
			<select name="col" style="width: 100%;">
				<option value="" selected="true" >...</option>
				<?php 
				if (count($col)>0 and !empty($col[0][0])) {
					for ($i = 0  ; $i < count($col) ; $i++){
						?>
						<option value="<?php echo $col[$i][0]; ?>"><?php echo $col[$i][1]; ?></option>
						<?php
					}
				}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td>
			<label for="tip">Tipo producto:</label>
		</td>
		<td>
			<!-- required="true" -->
			<select name="tip" style="width: 100%;">
				<option value="" selected="true">...</option>
				<?php 
				if (count($tip)>0 and !empty($tip[0][0])) {
					for ($i = 0  ; $i < count($tip) ; $i++){
						?>
						<option value="<?php echo $tip[$i][0]; ?>"><?php echo $tip[$i][1]; ?></option>
						<?php
					}
				}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td>
			<label for="des">Descripcion:</label>
		</td>
		<td>
			<!-- required="true" -->
			<input type="text" name="des" maxlength="500" >
		</td>
	</tr>
	<tr>
		<td>
			<label for="preci">Precio:</label>
		</td>
		<td>
			<!-- required="true" -->
			<input type="number" name="preci" maxlength="20" min="0" max="99999999999999999999" >
		</td>
	</tr>
	<tr>
		<td>
			<label for="visi">Visible?</label>
		</td>
		<td> 
			<!-- required="true" -->
			<input type="radio" name="visi" value="Si">&nbsp;Si &nbsp;&nbsp;&nbsp;&nbsp;
			<!-- required="true" -->
			<input type="radio" name="visi" value="No">&nbsp;No
		</td>
	</tr> 
	<tr>
		<td colspan="3">
			<input type="submit" name="btnProd" value="Agregar">
			<input type="button" value="Vaciar" onclick="javascript:location.reload()">
			<input type="button" value="Volver a menu" onclick="location.href='index.php';">
		</td>
	</tr>
</table>