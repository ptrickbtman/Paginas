function cargar(){
	dimensionarImgs();
}


function dimensionarImgs(){ 
	var imgs = document.getElementsByClassName('foto');

	for (var i=0; i<imgs.length; i++) {
		if(imgs[i].width > imgs[i].height){
			imgs[i].style.width = "100%";
		}else{
			imgs[i].style.height = "100%";
		}
	}
}


