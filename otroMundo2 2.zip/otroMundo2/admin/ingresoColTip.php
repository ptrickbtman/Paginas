<?php 
include 'controladores/crud.php'; 
$X="";
$x="";
if(isset($_POST['btn1']) || isset($_GET['btn1'])) {
	$X = "colores";
	$x = "Color";
}
if (isset($_POST['btn2']) || isset($_GET['btn2'])) {
	$X = "tipos";
	$x = "Tipo";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Gestionar <?php echo $x; ?></title>
</head>
<body>
	<div class="contIngreso">
		<div class="contForm">
			<form action="controladores/crudColTip.php" method="post">
				<?php 
				include "vistas/colTip.php"
				?>
			</form>
		</div>
	</div>
	<div class="contListar">
		<div class="contLis">
			<?php 
				include "vistas/ListColTip.php"
			?>
		</div>
	</div>
</body>
</html>