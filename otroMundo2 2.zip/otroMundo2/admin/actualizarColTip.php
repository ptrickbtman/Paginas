<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Gestionar <?php echo $_POST['colTip']; ?></title>
</head>
<body>
	<div class="contIngreso">
		<div class="contForm">
			<form action="controladores/crudColTip.php" method="post">
				<?php 
				if ($_POST['btnList']=='Editar') {
					include "vistas/colTipModi.php";
				}elseif($_POST['btnList']=='Eliminar'){
					include "vistas/colTipEli.php";
				}

				?>
			</form>
		</div>
	</div>
</body>
</html>