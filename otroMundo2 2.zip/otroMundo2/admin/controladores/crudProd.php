<?php
include 'crud.php'; 



echo '<pre>';
echo var_dump($t);
echo '</pre>';


if ($_POST['btnProd']=="Agregar") {
	$archivos = ordenarArchivos(10,'fotos');
	$atributos = array('NOM_COL');
	$datos = array(ucfirst($_POST['nom']));

}elseif ($_POST['btnProd']=="Modificar") {
	
}elseif ($_POST['btnProd']=="Eliminar") {
	
}
?>