<?php

 function conexion(){
    $server = "localhost";
    $user = "root";
    $pass = "";
    $bd = "bbawebde_casayplantabd2";
    $Conexion = mysqli_connect($server, $user, $pass, $bd);
    mysqli_set_charset($Conexion, "utf8");
    if (!$Conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    } 
    return $Conexion;
}


?>