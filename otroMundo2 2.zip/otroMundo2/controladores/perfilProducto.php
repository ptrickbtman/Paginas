
<?php
function perfil(){
    include 'vistas/perfilProducto.php';
   
}

?>