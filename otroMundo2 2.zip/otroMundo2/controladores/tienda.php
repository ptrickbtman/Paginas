<?php
include 'crud.php';


function tienda($reg,$inte){

    $tablas = array('productos','fotos');
    $atributos = array('productos.ID_PROD', 'productos.ID_COL', 'productos.ID_TIP', 'productos.NOM_PROD', 'productos.DES_PROD', 'productos.PRECI_PROD', 'fotos.ID_FOT', 'fotos.URL_FOT');
    $buscados = array('productos.VISI_PROD','productos.ID_PROD','fotos.PRIN_FOT');
    $parametros = array('Si', 'fotos.ID_PROD','Si');

    $min = 0;
    $max = 99999999999999999999;

    if(isset($_GET['colFil']) && !empty($_GET['colFil'])){
        array_push($buscados,"productos.ID_COL");
        array_push($parametros,$_GET['colFil']);

    }
    if(isset($_GET['tipFil']) && !empty($_GET['tipFil'])){
        array_push($buscados,"productos.ID_TIP");
        array_push($parametros,$_GET['tipFil']);
    }
    if(isset($_GET['minFil']) && !empty($_GET['minFil'])){
        $min= $_GET['minFil'];
    }
    if(isset($_GET['maxFil']) && !empty($_GET['maxFil'])){
        $max= $_GET['maxFil'];
    }



    $productos = MultiSelectEqualsBetweenLimit($tablas,$atributos,$buscados,$parametros,'PRECI_PROD',$min,$max,$reg,$inte);
    
    if (count($productos)>0 and !empty($productos[0][0])) {
        for ($i = 0  ; $i < count($productos) ; $i++){// por productos
            include 'vistas/tienda/catalogo.php';
        }
    }
}

function filtrado(){
    //no se me ocurrio como ordenarlos mas que una tabla
    ?>
    <br><br><br><br><br>
    <?php
    $atributos = array('ID_COL','NOM_COL');
    $col = Select('colores',$atributos);
    $atributos = array('ID_TIP','NOM_TIP');
    $tip = Select('tipos',$atributos);

    ?>
    <div class="contFilt">
        <form action="tienda.php" method="get">
            <table>
                <tr>
                    <td>
                        <label for="colFil">Color: </label>
                    </td>
                    <td>
                        <select name="colFil">
                            <option value=""<?php 
                            if (isset($_GET['colFil']) && !empty($_GET['colFil'])) {
                                echo $_GET['colFil'];
                                if($_GET['colFil']==""){
                                    echo 'selected="true"';
                                } 
                            }else{
                                echo 'selected="true"';
                            }
                            ?>>...</option>
                            <?php 
                            if (count($col)>0 and !empty($col[0][0])) {
                                for ($i = 0  ; $i < count($col) ; $i++){
                                    ?>
                                    <option value="<?php echo $col[$i][0]; ?>"<?php 
                                    if (isset($_GET['colFil']) && !empty($_GET['colFil'])) {
                                        if($_GET['colFil']==$col[$i][0]){
                                            echo 'selected="true"';
                                        } 
                                    }
                                    ?>><?php echo $col[$i][1]; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="tipFil">Tipo: </label>
                    </td>
                    <td>
                        <select name="tipFil">
                            <option value=""<?php 
                            if (isset($_GET['tipFil']) && !empty($_GET['tipFil'])) {

                                if($_GET['tipFil']==""){
                                    echo 'selected="true"';
                                } 
                            }else{
                                echo 'selected="true"';
                            }
                            ?>>...</option>
                            <?php 
                            if (count($tip)>0 and !empty($tip[0][0])) {
                                for ($i = 0  ; $i < count($tip) ; $i++){
                                    ?>
                                    <option value="<?php echo $col[$i][0]; ?>"<?php 
                                    if (isset($_GET['tipFil']) && !empty($_GET['tipFil'])) {
                                        if($_GET['tipFil']==$tip[$i][0]){
                                            echo 'selected="true"';
                                        } 
                                    }
                                    ?>><?php echo $tip[$i][1]; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="minFil">Precio min: </label>
                    </td>
                    <td>
                        <input type="number" min="0" max="99999999999999999999" name="minFil" value="<?php if(isset($_GET['minFil']) && !empty($_GET['minFil'])){echo($_GET['minFil']);} ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="maxFil">Precio max: </label>
                    </td>
                    <td>
                        <input type="number" min="0" max="99999999999999999999" name="maxFil" value="<?php if(isset($_GET['maxFil']) && !empty($_GET['maxFil'])){echo($_GET['maxFil']);} ?>">
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Filtrar">
                        <input type="button" value="Borrar filtros" onclick="location.href='Tienda.php';"> 
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <?php
}

function maxPaginas($cant,$inte){
    // $cant = cantidadDatos
    // $inte = cantidadDatosAMostrar
    while ($cant%$inte!=0) {
        $cant++;
    }
    return $cant/$inte;
    // retorna el numero de pagina mas grande
}

function paginacion($max,$destino){
    ?>
    <form action="<?php echo $destino; ?>" method="get">
        <table>
            <tr>
                <?php  
                if ($max>1) {
                    for ($i=1; $i <= $max ; $i++) { 
                        ?><td><input type="submit" name="pag" value="<?php echo $i; ?>"></td><?php
                    }
                }
                ?>
            </tr>
        </table>
    </form>
    <?php
}
?>