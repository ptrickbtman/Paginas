<?php
    session_start();
    include "crud.php";
    if (isset($_POST["idPro"])){
        $idProducto = $_POST["idPro"];
        //echo $idProducto;
        $conexion = BDconex();
        $pasa ="";
        $sentencia = "SELECT productos.ID_PROD, productos.NOM_PROD, productos.PRECI_PROD, fotos.URL_FOT FROM productos, fotos WHERE fotos.ID_PROD = productos.ID_PROD AND productos.VISI_PROD ='Si' AND productos.ID_PROD='". $idProducto ."'";
        if ($result = $conexion->query($sentencia)) {
            $filas = $result->num_rows;
            if ($filas == 1){ 
                if (isset($_SESSION['carrito']) and !empty(isset($_SESSION['carrito']))) { 
                    // aqui va el if Si es que se repite el producto
                    $productos = $_SESSION['carrito'];
                    for ($i =0; $i<count($_SESSION['carrito']) ; $i++){
                        //echo ($productos[$i][0]."". "". $idProducto );
                        if($productos[$i][0] ==  $idProducto){   
                            $pasa = "no";
                        }else if ($i == count($_SESSION['carrito'])-1 and  $productos[$i][0] !=  $idProducto ) {
                            $pasa = "si";
                        }
                    }
                    if ($pasa == "si"){
                        $cantidadProd = count(array_values($_SESSION['carrito']))+1;
                        llenarCarrito(1,$result, $cantidadProd);   
                    }else{
                        echo "no";
                    }
                }else{
                    llenarCarrito(0,$result, 0);
                }
            }
        }  
    }else if (isset($_POST['idProdElimi']) and isset($_SESSION['carrito']) ){
        eliminarProductoCarrito($_POST['idProdElimi']);
    }

function llenarCarrito($producto, $result, $cantidadProd){
    print_r("paso");
    if ($producto ==1){
        $productos = $_SESSION['carrito'];
    }
    while ($datosProducto = mysqli_fetch_row($result)) {               
        $productos[$cantidadProd ][0] = $datosProducto[0];
        $productos[$cantidadProd][1] = $datosProducto[1];
        $productos[$cantidadProd][2] = $datosProducto[2];
        $productos[$cantidadProd][3] = $datosProducto[3];
   }
    $_SESSION["carrito"] = array_values($productos);
    print_r($_SESSION["carrito"]);
}

function eliminarProductoCarrito($id){
    $productos = $_SESSION['carrito'];
    unset($productos[$id]);
    $_SESSION['carrito']= array_values($productos);
    
    if (count( $_SESSION['carrito']) == 0 ){
        session_destroy();
        print_r("no datos");
    }else{
        print_r( $_SESSION['carrito']);
    }   
}

?>