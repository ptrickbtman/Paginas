<?php 
function conocenos() {
    include 'vistas/quienesSomos.php';
}


function DesplegarMenu() {
    include 'vistas/menu.php';
}




?>