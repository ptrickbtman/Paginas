<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>carrito</title>
    <script src="../js/jquery.js"></script>
    <script src="script.js"></script>
</head>
<body>
<?php 
session_start();

?>

<form class="form">
        <input name="precio" type ="hidden" value="2">
        <input name="nombre" type ="hidden" value="asdsad">
        <input type="button" class="btn" onclick="getFormData()" value="añadir">
</form>



<div id='contenedorCarrito'>
<div class="content">
<?php

if (isset($_SESSION['carrito']) ) {
    $longitud = count($_SESSION['carrito']);
    
    for($i=0; $i<$longitud; $i++){
    echo $_SESSION['carrito'][$i][0];
    echo "<br>";
    echo $_SESSION['carrito'][$i][1];
    echo "<br>";
    echo "<br>";
}
}

?>
</div>
</div>

</body>
</html>