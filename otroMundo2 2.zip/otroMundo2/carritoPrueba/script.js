function getFormData(formId) {
    var url = "./script.js";
    $.getScript(url);
    var dataArray = $('.' + 'form').serializeArray(),
        dataObj = {};
    $(dataArray).each(function(i, field) {
        dataObj[field.name] = field.value;
    });
    var producto = [dataObj['nombre'], dataObj['precio']]; // ATRIBUTOS PARA EL CARRITO DE COMPRAS 
    $.ajaxPrefilter(function(options, original_Options, jqXHR) {
        options.async = true;
    });

    $.ajax({
        async: true,
        data: { "parametro": producto },
        type: "POST",
        url: "carrito2.php",
        // Si el 3cambio se realiza correctamente: 
        success: function(nuevaCantidad) {
            console.log(nuevaCantidad);
            $("#contenedorCarrito").load("carrito1.php" + ' .content');
        }
    });
}