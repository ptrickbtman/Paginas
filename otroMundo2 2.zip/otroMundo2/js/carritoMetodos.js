function eliminarProdCarrito(id) {
    cerrarCarrito()
    setTimeout(function() {
        var dataArray = $('.' + 'formEliminar' + id).serializeArray(),
            dataObj = {};
        $(dataArray).each(function(i, field) {
            dataObj[field.name] = field.value;
        });
        if (id == dataObj['idProdEli']) {
            $.ajax({
                async: true,
                data: { "idProdElimi": id },
                type: "POST",
                url: "./controladores/carrito.php",
                // Si el 3cambio se realiza correctamente: 
                success: function(nuevaCantidad) {
                    console.log(nuevaCantidad);
                    actualizarCarrito();
                }
            });
        }
    }, 300)
}

function actualizarCarrito() {
    cerrarCarrito();
    setTimeout(function() {
        $(".contenCarrito").load(window.location + ' .contenCarrito');
    }, 500)
}

function cerrarCarrito() {
    if ($(".carritoCont").hasClass("carritoContOn")) {
        $(".carritoCont").removeClass("carritoContOn");
    }
}

function añadirCarrito() {
    obtenerIdProducto();
}

function obtenerIdProducto() {
    cerrarCarrito();

    var dataArray = $('.' + 'formEnvio').serializeArray(),
        dataObj = {};
    $(dataArray).each(function(i, field) {
        dataObj[field.name] = field.value;
    });
    // alert(dataObj['idProducto'])

    $.ajaxPrefilter(function(options, original_Options, jqXHR) {
        options.async = true;
    });

    $.ajax({
        async: true,
        data: { "idPro": dataObj['idProducto'] },
        type: "POST",
        url: "./controladores/carrito.php",
        // Si el 3cambio se realiza correctamente: 
        success: function(productos) {
            console.log(productos);
            if (productos == "no") {
                alert("Producto ya esta añadido!")
                cerrarModal();
            } else {
                actualizarCarrito();
                cerrarModal();
            }


        }
    });

}


function cerrarModal() {
    $(".modal").css({
        "height": "0vh",
        "opacity": "0"
    });
    setTimeout(function() {
        borrarContenidoModal();
    }, 500);

}

function borrarContenidoModal() {

    $(".titModal").remove();
    $(".imgCatalogo3").remove();
    $(".desModal").remove();
    $(".precioModal").remove();
    $(".btnFormCarrito").remove();
}