$(document).ready(function() {
    setTimeout(function() {
        ajustarImg()
    }, 300)
});



function cargarDatos(dato) {
    //    alert(dato)
    var dataArray = $('.' + 'form' + dato.toString()).serializeArray(),
        dataObj = {};
    $(dataArray).each(function(i, field) {
        dataObj[field.name] = field.value;
    });
    var producto = [dataObj['id'], dataObj['titProducto'], dataObj['desProducto'], dataObj['precioProducto'], dataObj['url']]; // ATRIBUTOS PARA EL CARRITO DE COMPRAS 
    //    alert(producto)
    crearModal(producto);

}

function crearModal(producto) {

    cerrarCarrito();

    // agregamos los datos al modal
    $('.contenedorFotoModal').append(' <img src="' + producto[4] + '" class="imgCatalogo3" alt="img no encontrada">')
    ajustarImg(producto[4]);
    $('.contenidoProducto').append('<p class="titModal">' + producto[1] + '</p>' +
        '<p class="desModal">' + producto[2] + '</p>' +
        '<p class="precioModal"> $ ' + producto[3] + '</p>' +
        '<form class="formEnvio">' +
        '<input class="btnFormCarrito btnFormCarrito2" type="button" value="Atras" onclick="cerrarModal()">' +
        '<input  type="hidden" value="' + producto[0] + '" name="idProducto">' +
        '<input class="btnFormCarrito" type="button" value="Añadir" onclick="añadirCarrito()">' +
        '</form>');
    ajusteImgModal()
    $(".modal").css({
        "height": "100vh",
        "opacity": "1"
    });
}

function ajusteImgModal() {
    var as2 = document.getElementsByClassName('imgCatalogo3')
    var ancho2 = as2[0].width;
    var alto2 = as2[0].height;
    if (ancho2 > alto2) {
        as2[0].style.width = "100%";
        as2[0].style.opacity = "1";
    } else {
        as2[0].style.height = "100%";
        as2[0].style.opacity = "1";

    }

}

function cerrarModal() {
    $(".modal").css({
        "height": "0vh",
        "opacity": "0"
    });
    setTimeout(function() {
        borrarContenidoModal();
    }, 500)

}

function cerrarCarrito() {
    $(".contenCarrito").removeClass("contenCarritoOn");
}

function borrarContenidoModal() {

    $(".titModal").remove();
    $(".imgCatalogo2").remove();
    $(".desModal").remove();
    $(".precioModal").remove();
    $(".btnFormCarrito").remove();
}

function ajustarImg() {

    var as2 = document.getElementsByClassName('imgCatalogo2')


    for (var i = 0; i < as2.length; i++) {
        var ancho2 = as2[i].width;
        var alto2 = as2[i].height;
        if (ancho2 > alto2) {
            as2[i].style.height = "100%";
            as2[i].style.opacity = "1";
        } else {
            as2[i].style.width = "100%";
            as2[i].style.opacity = "1";

        }
    }


}

function añadirCarrito() {

    obtenerIdProducto();
    /*  borrarModal2();
      modalRespuestaCarrito(); */
}

function obtenerIdProducto() {
    var dataArray = $('.' + 'formEnvio').serializeArray(),
        dataObj = {};
    $(dataArray).each(function(i, field) {
        dataObj[field.name] = field.value;
    });

    $.ajaxPrefilter(function(options, original_Options, jqXHR) {
        options.async = true;
    });

    $.ajax({
        async: true,
        data: { "idPro": dataObj['idProducto'] },
        type: "POST",
        url: "./controladores/carrito.php",
        // Si el 3cambio se realiza correctamente: 
        success: function(nuevaCantidad) {
            console.log(nuevaCantidad);
            $(".contenCarrito").load(window.location + ' .carritoCont');
        }
    });

}
/*
function borrarModal2() {

    setTimeout(function() {
        borrarContenidoModal();
        añadirLoadingModal();
    }, 500)
}

function añadirLoadingModal() {
    $(".modal").css({
        "opacity": "1"
    });
    $(".modal").append('<div class="loading"></div>');
}
*/