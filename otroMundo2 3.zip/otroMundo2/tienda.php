<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mundo | Catalogo</title>
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/tienda.css">

    <script src="js/jquery.js"></script>
    <script src="js/cargado.js"></script>
    <script src="js/imagenGaleria.js"></script>
    <script src="js/catalogo.js"></script>
    <script src="js/carritoMetodos.js"></script>
    <script src="https://kit.fontawesome.com/fd543783d4.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
    include 'controladores/metodosPrincipales.php';
    include 'controladores/tienda.php'; 


    //-----Datos paginacion--------

    $pagAct=1;// Pagina actual
    if(isset($_GET['pag']) && !empty($_GET['pag'])){
        $pagAct = $_GET['pag'];
    }
    $registroIni=0;// Registro inicial
    $intervalo=9;// intervalo de registros
    if ($pagAct>1) {
        $registroIni = $intervalo*($pagAct-1);
    }

    $buscadosCount =  array('VISI_PROD');
    $parametrosCount = array('Si');

    $min = 0;
    $max = 99999999999999999999;

    if(isset($_POST['colFil']) && !empty($_POST['colFil'])){
        array_push($buscadosCount,"ID_COL");
        array_push($parametrosCount,$_POST['colFil']);

    }
    if(isset($_POST['tipFil']) && !empty($_POST['tipFil'])){
        array_push($buscadosCount,"ID_TIP");
        array_push($parametrosCount,$_POST['tipFil']);
    }
    if(isset($_POST['minFil']) && !empty($_POST['minFil'])){
        $min= $_POST['minFil'];
    }
    if(isset($_POST['maxFil']) && !empty($_POST['maxFil'])){
        $max= $_POST['maxFil'];
    }

    $maxPag = SelectCountEquals('productos','ID_PROD',$buscadosCount,$parametrosCount,'PRECI_PROD',$min,$max);


    //-----------------------------


    DesplegarMenu();
    filtrado();
    
    ?>

    <div class="contenedorProductos">
        <?php
        tienda($registroIni,$intervalo);
        ?>
    </div>    
    <div class="contenedorPaginas">
        <?php
        paginacion(maxPaginas($maxPag,$intervalo),'tienda.php');
        ?>
    </div>


        

        <div class="modal">
            <div class="left">
                <div class="contenedorFotoModal">
                
                </div>
            </div>
            <div class="right">
                <div class="contenidoProducto">

                </div>
            </div>
        
        </div>

</body>
</html>