<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago | Mundo-Purpura</title>
    <!-- menu  -->
    <link rel="stylesheet" href="css/menu.css">
    <script src="js/jquery.js"></script>
    <script src="js/cargado.js"></script>
    <script src="https://kit.fontawesome.com/fd543783d4.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="css/pago.css">
    <!-- menu  --> 

    <script src="js/pago.js"></script>
</head>
<body>
<?php
    include 'controladores/metodosPrincipales.php'; //contiene conocenos()
    include 'controladores/pago.php';
    
    DesplegarMenu();
    DesplegarFormulariopago();


    
?>

</body>
</html>