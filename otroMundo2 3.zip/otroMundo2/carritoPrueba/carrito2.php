<?php
    // Obtienes la cantidad a sumar
    $sumCant = $_POST["parametro"];

    // Abres la session y le sumas el valor
    session_start();
    
    if (isset($_SESSION["carrito"])){
        $productos = $_SESSION["carrito"];
        $espacio = count($productos);
        $productos[$espacio][0] = $sumCant[0];
        $productos[$espacio][1]= $sumCant[1];
    }else{
        
        $productos[0][0] = $sumCant[0];
        $productos[0][1]= $sumCant[1];
    }


    
    $_SESSION["carrito"] = $productos;

    // Devuelves el nuevo valor para actualizar la pagina
    //echo $_SESSION["carrito"];
    print_r($productos);

?>