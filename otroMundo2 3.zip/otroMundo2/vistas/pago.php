
<?php
//unset($_SESSION["cliente"]);
?>


<div class="containerForm" style="transform: translateY(120px);">
    <form  class="formEnvio">
        <label class="text">Rut:</label>
        <input type="text" name="rut" placeholder="00.000.000-0">
        <label class="text">Nombre:</label>
        <input type="text" placeholder="Juan" name="nombre">
        <label class="text">Apellido:</label>
        <input type="text" placeholder="Soto" name="apellido">
        <label class="text">Email:</label>
        <input type="email" placeholder="xxxxxxxx@gmail.com" name="email">
        
        <label class="text">Region</label>
        <select name="region">
            <option value="0">...</option>
            <option value="1">| Tarapacá, Iquique</option> 
            <option value="2">|| Antofagasta</option>
            <option value="3">| Atacama, Copiapó</option>
            <option value="4">| Coquimbo, La Serena</option>
            <option value="5">| Valparaíso</option>
            <option value="6">| O'Higgins, Rancagua</option>
            <option value="7">| Maule, Talca</option>
            <option value="8">| Bío-Bío, Concepción</option>
            <option value="9">| Araucanía, Temuco</option>
            <option value="10">| Los lagos, Puerto Montt</option>
            <option value="11">| Aysen, Coyhaique</option>
            <option value="12">| Magallanes, Punta Arenas</option>
            <option value="13">| Metropolitana, Santiago</option>
            <option value="14">| Los Rios, Valdivia</option>
            <option value="15">| Arica y Parinacotao</option>
        </select>
       
        <label class="text">Dirección:</label>
        <input type="text" placeholder="Pasj, Calle #123" name="direccion">
        <label class="text">Número Cel:</label>
        <input type="number" placeholder="9 99999999" name="numero">
        <input type="button" value="Validar Datos" class="btnValidar" onclick="validar()">

    </form>
</div>

<div class="modalDatosValidados">


    <div class="actualizarModal">
        <div class="contenedorModalDatos">
        <?php 
            if (isset($_SESSION["cliente"])){
                $cliente = $_SESSION["cliente"];
                foreach ($cliente as $val) {
                    echo "<p class='textModaPago'>".$val. "</p>";
                }
            }
        ?>   
        </div>
    </div>

    <div class="pago">
    <?php     
        include 'controladores/pagoMercado.php';
    ?> 
    </div> 

</div>

<div class="modalEspera">
    <div class="loading"></div>
</div>
