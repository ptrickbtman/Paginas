<?php 
//session_start();
//session_destroy() ?>

<script src="js/carritoMetodos.js"></script>


<div class="load">
    <div class="circle"></div>
</div>

<div class="menu">

    <div class="hamburguer">
        <div class="stick stick1"></div>
        <div class="stick stick2"></div>
        
    </div>

    <div class="carrito">
        <div onclick="abrirCarrito()" class="contentCarrito">
            <i class="fas fa-shopping-cart" ></i>
        </div>
    </div>
</div>

<div class="contentItemsMenu ">
        <div class="contentMenu">
            <p class="items">Inicio</p>
            <p class="items">Catalogo</p>
            <p class="items">Contactos</p>
            <p class="items">Conócenos</p>
        </div>
</div>


<div class="carritoCont">
    <div class="contenCarrito">
        <?php 
        session_start();
            //llenamos los datos del carrito
            if(isset($_SESSION['carrito']) and !empty($_SESSION['carrito']) ){
                $productos = $_SESSION['carrito'];
                $totalPagar =0;
                for ($i = 0; $i<count($productos); $i++){
                    echo "<div class=''contenedorProCarrito>";
                        echo "<div class='imgProCarrito'>";
                        echo "</div>";

                        echo "<div class='infoProCarrito'>";
                          //  echo "<p>".$productos[$i][0]." </p>";
                            echo "<p>".$productos[$i][1]." </p>";
                            echo "<p>".$productos[$i][2]." </p>";
                            echo "<p>".$productos[$i][3]." </p>";
                            $totalPagar +=$productos[$i][2];
                            ?>
                            <!-- formulario para eliminar el producto del carrito -->
                            <form class="formEliminar<?php echo $i?>">
                            <input type="hidden" value="<?php echo $i?>" name="idProdEli" class="idProdInput<?php echo $productos[$i][0]?>" >
                                <input type="button" value="eliminar" onclick="eliminarProdCarrito(<?php echo $i ?>)">
                            </form>


                            <?php 
                            
                        echo "</div>";

                    echo "</div>";
                }
                echo "Total a pagar: ".$totalPagar;
                echo "<button class='pagar' onclick='irPagar()'> Pagar </button>";

            }else{

                echo "<p>No hay productos añadidos</p>";
            }

        ?>

    </div>
</div>