
<div class="containerQuienes">
    <div class="leftQuienes">
        <div class="contenQuienes">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/8DlbDXcWMpg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
    <div class="rightQuienes">
        <div class="contenQuienes">
            <p class="textQuienes">Cada Cartera de Mundo Purpura es una  pieza unica y original, creada a mano con fieltro de lana de oveja y teñida de manera artesanal. Diseñada por Violeta Chiang a partir del color y la textura del fieltro, se mezclan los materiales y las texturas en los distintos detalles de cada cartera, buscando el contraste. Tenemos una coleccion con 4 modelos para las distintas necesidades.</p>
        </div>
    </div>

</div>