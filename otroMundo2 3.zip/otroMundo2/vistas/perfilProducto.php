

<div class="contenedoPerfilProducto">
    <div class="leftPerfilProducto">
        <div class="contenedorFoto">
        
        </div>
    </div>


    <div class="rightPerfilProducto">
        <div class="contenedorInfoProducto">
            <p class="tittle"></p>
            <p class="descripcion"></p>
            <p class="precio"></p>
            <form action="">
                

            </form>
        </div>
    </div>

</div>