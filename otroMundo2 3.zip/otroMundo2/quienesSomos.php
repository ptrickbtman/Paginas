<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conocenos!</title>
    <!-- menu  -->
    <link rel="stylesheet" href="css/menu.css">
    <script src="js/jquery.js"></script>
    <script src="js/cargado.js"></script>
    <script src="https://kit.fontawesome.com/fd543783d4.js" crossorigin="anonymous"></script>
    <!-- menu  --> 

    <link rel="stylesheet" href="css/quienesSomos.css">
</head>
<body>
<?php
    include 'controladores/metodosPrincipales.php'; //contiene conocenos()
    
    DesplegarMenu();
    conocenos();
   // filtrado();
    
?>

    
</body>
</html>