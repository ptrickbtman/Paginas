<?php
// SDK de Mercado Pago
require  /* __DIR__ .  */ 'mercadoPagoCompouser/vendor/autoload.php';
MercadoPago\SDK::setAccessToken('TEST-1519902854743318-062420-bb56c7574aa83886ce0fa62b3fea18e2-113885956');


// Crea un objeto de preferencia
$preference = new MercadoPago\Preference();

// Crea un ítem en la preferencia
$item = new MercadoPago\Item();
$item->title = 'Mi producto';
$item->quantity = 1;
$item->unit_price = 100;
$preference->items = array($item);
$preference->save();


?>

<form action="controladores/pagoMercado.php" method="POST"><script src="https://www.mercadopago.cl/integrations/v1/web-payment-checkout.js" data-preference-id="<?php echo $preference->id; ?>"></script></form> 


