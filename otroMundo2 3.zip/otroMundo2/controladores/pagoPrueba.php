<?php
 echo '<form action="pagoMercado.php" method="POST"><script src="https://www.mercadopago.cl/integrations/v1/web-payment-checkout.js" data-preference-id="<?php echo $preference->id; ?>"></script></form> ';  
?>