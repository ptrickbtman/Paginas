
<?php 

$data = $_POST["data"];

// echo 1 para la validacio, de todon 
 // rut nombre apellido email region direccion numero
// print_r($data);
if(isset($data)){
    if (validarRut($data['rut'])){
        if(validarLetras($data['nombre'])){
            if (validarLetras(($data['apellido']))){
                if (validarEmail(($data['email']))){
                    if ((int)$data['region'] != 0 ){
                        if(strlen($data['direccion']) !=0){
                            echo llenarCliente($data);
                        }else{
                            return False;
                        }
                    }else{
                        return False;
                    }
                }else{
                    return False;
                }
            }else{
                return False;
            }
        }else{
            return False;
        }
    }else{
        return False;
    }
}else{
    return False;
}


function llenarCliente($data){
    //rut nombre apellido email region direccion numero;
    session_start();
    if(isset($_SESSION['cliente'])){
        $clinte = $_SESSION['cliente'];
    }
    $clinte[0] = $data['rut'] ;
    $clinte[1] = $data['nombre'] ;
    $clinte[2] = $data['apellido'];
    $clinte[3] = $data['email'] ;
    $clinte[4] = $data['region'] ;
    $clinte[5] = $data['direccion'];
    $clinte[6] = $data['numero'];
    $_SESSION['cliente'] = $clinte;
    return 1;
}



function validarLetras($datos) {
        if (ctype_alpha($datos)) {
            return True;            
        } else {
            return False;
        }
}

function validarNum($data){
    if (ctype_digit($data)) {
        return True;
    } else {
        return False;
    }
}

function  validarEmail($data) {
    if (filter_var($data, FILTER_VALIDATE_EMAIL)) {
        return True;
    }else {
        return False;
    }
}


function validarRut($rut){
    if (isset($rut)) { 
        $largo =  strlen($rut);
        if ($largo < 7) {
        }else{
            if (strpos($rut, "-")){
                $rut_sin_puntos = str_replace('.', "", $rut); //elimino puntos
                $pos = strpos($rut_sin_puntos,"-");
                $numerosentrada = explode("-", $rut_sin_puntos); 
                $verificador = $numerosentrada[1];
                $numeros = strrev($numerosentrada[0]); 
                $count = strlen($numeros); 
                $count = $count -1; 
                $suma = 0;
                $recorreString = 0;
                $multiplo = 2;
                for ($i=0; $i <=$count ; $i++) {  
                    $resultadoM = $numeros[$recorreString]*$multiplo;
                    $suma = $suma + $resultadoM; 
                    if ($multiplo == 7) { 
                        $multiplo = 1;
                    }
                    $multiplo++;
                    $recorreString++;
                }
                $resto = $suma%11;
                $dv= 11-$resto;
                $dvM = $dv;

                if ($dv == 11) {
                    $dv = 0;
                    $dvM = 0;
                }   
                if ($dv == 10) {
                    $dv = "k";
                    $dvM = "K" ;
                }
                if ($verificador == $dv || $verificador == $dvM) {
                    return True;
                }else {
                    return False;
                }
            }else{
                return False;
            }
        }
    }else{
        return False;
    }
}
?>