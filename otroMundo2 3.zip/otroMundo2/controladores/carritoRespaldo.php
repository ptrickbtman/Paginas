<?php
    session_start();
  // borrarSession();

    include "crud.php";
    if (isset($_POST["idPro"])){
        $idProducto = $_POST["idPro"];
        $conexion = BDconex();
        $sentencia = "SELECT productos.ID_PROD, productos.NOM_PROD, productos.PRECI_PROD, fotos.URL_FOT FROM productos, fotos WHERE fotos.ID_PROD = productos.ID_PROD AND productos.VISI_PROD ='1' AND productos.ID_PROD=". $idProducto. "";
        if ($result = $conexion->query($sentencia)) {
            $filas = $result->num_rows;

            if ($filas == 1){  
                
                if (isset($_SESSION['carrito'])){

                    $productos = $_SESSION['carrito'];
                    $cantidadProd = count(array_values($_SESSION['carrito']))+1;
                    echo $cantidadProd;
                    echo "<br>";
                    while ($datosProducto = mysqli_fetch_row($result)) {
                       
                        $productos[$cantidadProd][0] = $datosProducto[0];
                        $productos[$cantidadProd][1] = $datosProducto[1];
                        $productos[$cantidadProd][2] = $datosProducto[2];
                        $productos[$cantidadProd][3] = $datosProducto[3];
                   }
                    $_SESSION["carrito"] = $productos;
                    print_r($_SESSION["carrito"]);
                }else{
                    $cantidadProd = 0 ;
                    while ($datosProducto = mysqli_fetch_row($result)) {
                        $productos[$cantidadProd][0] = $datosProducto[0];
                        $productos[$cantidadProd][1] = $datosProducto[1];
                        $productos[$cantidadProd][2] = $datosProducto[2];
                        $productos[$cantidadProd][3] = $datosProducto[3];
                   }
                    $_SESSION["carrito"] = array_values($productos);
                    print_r($_SESSION["carrito"]);
                    echo "añadido1";
                }
            }
        }      
    }  
?>