<?php
//funcion para conectar con la bd  
function BDconex(){
	$server = "localhost";
	$user = "root";
	$pass = "";
	$bd = "bdmundopurpura";

	$con = mysqli_connect($server, $user, $pass, $bd);

//	if (!$con) {
// 	echo("Conexion fallida: " . mysqli_connect_error());
//	}
//	echo "Conexion establecida";
	return $con; 
}

function Select($nomTab,$atriTab){
	// $nomTab = "nombreTabla"
	// $atriTab = array("AtributoTabla1","AtributoTabla2","AtributoTabla3",Etc..)
	$con = BDconex();
	$sql = "SELECT ";

	for ($i=0; $i < count($atriTab); $i++) { 
		$sql .= $atriTab[$i];
		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " FROM ".$nomTab;
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	$result = mysqli_query($con, $sql);
	$datos[0][0]=null;
	if (mysqli_num_rows($result) > 0) {
		$x = 0;
		while($row = mysqli_fetch_assoc($result)) {
			for ($i=0; $i <count($atriTab) ; $i++) { 
				$datos[$x][$i] = $row[$atriTab[$i]];
			}
			$x++;
		}
	}
	mysqli_close($con);
	return $datos;
	// Retorna un array bidimensional $array[$i][$x]
}

function SelectEquals($nomTab,$atriTab,$atriBusc,$param){
	// $nomTab = "nombreTabla"
	// $atriTab = array("AtributoTabla1","AtributoTabla2","AtributoTabla3",Etc..)
	// $atriBusc = " WHERE ..." array("AtributoBuscado1","AtributoBuscado2","AtributoBuscado3",Etc..)
	// $param = " = ...    " array("Parametro1","Parametro1","Parametro1",Etc..)
	$con = BDconex();
	$sql = "SELECT ";

	for ($i=0; $i < count($atriTab); $i++) { 
		$sql .= $atriTab[$i];
		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " FROM ".$nomTab." WHERE ";

	for ($i=0; $i < count($atriBusc); $i++) { 
		$sql .= $atriBusc[$i]." = '".$param[$i]."'";
		if ($i != count($atriBusc)-1) {
			$sql .= " AND ";
		}
	}
	//echo '<script language="javascript">alert("'.$sql.'");</script>';

	$result = mysqli_query($con, $sql);
	$datos[0][0]=null;
	if (mysqli_num_rows($result) > 0) {
		$x = 0;
		while($row = mysqli_fetch_assoc($result)) {
			for ($i=0; $i <count($atriTab) ; $i++) { 
				$datos[$x][$i] = $row[$atriTab[$i]];
			}
			$x++;
		}
	}
	mysqli_close($con);
	return $datos;
	// Retorna un array bidimensional $array[$i][$x]
}


function MultiSelectEqualsBetweenLimit($nomTab,$atriTab,$atriBusc,$param,$AtriBetween,$min,$max,$numInicio,$numIntervalo){
	// $nomTab = array(nombreTabla1,nombreTabla2,etc)
	// $atriTab = array("AtributoTabla1","AtributoTabla2","AtributoTabla3",Etc..)
	// $atriBusc = " WHERE ..." array("AtributoBuscado1","AtributoBuscado2","AtributoBuscado3",Etc..)
	// $param = " = ...    " array("Parametro1","Parametro1","Parametro1",Etc..)
	// $AtriBetween = "atributoAComparar"
	// $min "valor min"
	// $max "valor max"
	// $numInicio = numeroinicial
	// $numIntervalo = cantidadAMostrar
	$con = BDconex();
	$sql = "SELECT ";

	for ($i=0; $i < count($atriTab); $i++) { 
		$sql .= $atriTab[$i];
		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " FROM ";
	for ($i=0; $i < count($nomTab); $i++) { 
		$sql .= $nomTab[$i];
		if ($i != count($nomTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " WHERE ";
	for ($i=0; $i < count($atriBusc); $i++) { 

		$sql .= $atriBusc[$i]." = ";
		if (stripos($param[$i], '.')) {
			$sql .= $param[$i];
		}else{
			$sql .= "'".$param[$i]."'";
		}
		if ($i != count($atriBusc)-1) {
			$sql .= " AND ";
		}
	}
	$sql .= " AND (".$AtriBetween." BETWEEN ".$min." AND ".$max.") LIMIT ".$numInicio.", ".$numIntervalo;

	//echo '<script language="javascript">alert("'.$sql.'");</script>';

	$result = mysqli_query($con, $sql);
	$datos[0][0]=null;
	if (mysqli_num_rows($result) > 0) {
		$x = 0;
		while($row = mysqli_fetch_assoc($result)) {
			for ($i=0; $i <count($atriTab) ; $i++) { 
				$atri = explode('.', $atriTab[$i]);
				$datos[$x][$i] = $row[$atri[1]];
			}
			$x++;
		}
	}
	mysqli_close($con);
	return $datos;
	// Retorna un array bidimensional $array[$i][$x]
}

function SelectCountEquals($nomTab,$atriTab,$atriBusc,$param){
	// $nomTab = "nombreTabla"
	// $atriTab = "atributoTabla"
	// $atriBusc = " WHERE ..." array("AtributoBuscado1","AtributoBuscado2","AtributoBuscado3",Etc..)
	// $param = " = ...    " array("Parametro1","Parametro1","Parametro1",Etc..)
	$con = BDconex();
	$sql = "SELECT COUNT(".$atriTab.") FROM ".$nomTab." WHERE ";

	for ($i=0; $i < count($atriBusc); $i++) { 
		$sql .= $atriBusc[$i]." = '".$param[$i]."'";
		if ($i != count($atriBusc)-1) {
			$sql .= " AND ";
		}
	}

	$result = mysqli_query($con,$sql);
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	$data = mysqli_fetch_assoc($result);
	return $data['COUNT('.$atriTab.')'];
	
}



?>