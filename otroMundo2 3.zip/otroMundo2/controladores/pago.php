<?php 

function DesplegarFormulariopago(){
    //session_start();
    if (isset($_SESSION['carrito']) and !empty($_SESSION['carrito'])){
        $productos = $_SESSION['carrito'];  // variable
        include 'vistas/pago.php';

    }



    


}

?>