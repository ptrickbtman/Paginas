$(document).ready(function() {
    var as = document.getElementsByClassName('imgCatalogo');
    for (var i = 0; i < as.length; i++) {
        var ancho = as[i].width;
        var alto = as[i].height;
        if (ancho > alto) {
            as[i].style.width = "100%";
        } else {
            as[i].style.height = "100%";
        }
    }
});