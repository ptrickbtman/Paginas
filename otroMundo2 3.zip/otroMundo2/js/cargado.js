$(document).ready(function() {
    $(".hamburguer").on("click", function() {
        $(".menu").toggleClass("menuOn");
        $(".stick1").toggleClass("stick1On");
        $(".stick2").toggleClass("stick2On");
        $(".contentItemsMenu").toggleClass("contentItemsMenuOn");

    });
});


function abrirCarrito() {
    $(".carritoCont").toggleClass("carritoContOn");
}

function irTienda() {
    location.href = "tienda.php";
}

function irContacto() {
    location.href = "contacto.php";
}

function irQuienes() {
    location.href = "quienesSomos.php";
}

function irPagar() {
    location.href = "pago.php";
}