function validar() {
    var dataArray = $('.' + 'formEnvio').serializeArray(),
        dataObj = {};
    $(dataArray).each(function(i, field) {
        dataObj[field.name] = field.value;
    });
    // rut nombre apellido email region direccion numero
    $.ajaxPrefilter(function(options, original_Options, jqXHR) {
        options.async = true;
    });

    $.ajax({
        async: true,
        data: { "data": dataObj },
        type: "POST",
        url: "./controladores/validacionDatosPago.php",
        // Si el 3cambio se realiza correctamente: 
        success: function(data) {
            console.log(data);

            if (data == 1) {
                actualizarData();

            } else {

            }

        }
    });
}



function actualizarData() {
    $(".actualizarModal").load(window.location + ' .contenedorModalDatos');
    //$(".modalDatosValidados").load(window.location + ' .pago');
    //$(".actualizarPago").load(window.location + ' .pago');



    setTimeout(function() {
        $(".modalDatosValidados").css({
            "opacity": "1",
            "height": "100vh"
        });
    }, 500)
}