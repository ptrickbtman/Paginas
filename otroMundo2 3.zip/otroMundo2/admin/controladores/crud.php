<?php  
//funcion para conectar con la bd  
function BDconex(){
	$server = "localhost";
	$user = "root";
	$pass = "";
	$bd = "bdmundopurpura";

	$con = mysqli_connect($server, $user, $pass, $bd);

//	if (!$con) {
// 	echo("Conexion fallida: " . mysqli_connect_error());
//	}
//	echo "Conexion establecida";
	return $con; 
}
function ordenarArchivos($cant,$namePost) {

	$arrayFile = array();

	for ($i=0; $i<$cant; $i++) {
		if (!empty($_FILES[$namePost]['name'][$i])) {
			$nam = $_FILES[$namePost]['name'][$i];
			if (stripos($nam, 'png')||stripos($nam, 'PNG')||stripos($nam, 'jpg')||stripos($nam, 'JPG')||stripos($nam, 'jpeg')||stripos($nam, 'JPEG')) {
				$arrayFile[$i]['name'] = $nam; 
				$arrayFile[$i]['type'] = $_FILES[$namePost]['type'][$i];
				$arrayFile[$i]['tmp_name'] = $_FILES[$namePost]['tmp_name'][$i];
				$arrayFile[$i]['error'] = $_FILES[$namePost]['error'][$i];
				$arrayFile[$i]['size'] = $_FILES[$namePost]['size'][$i];
			}
		}
	}

	return array_values($arrayFile);
}
function Insert($nomTab,$atriTab,$datos){
	// $nomTab = "nombreTabla"
	// $atriTab = array("AtributoTabla","AtributoTabla","AtributoTabla",Etc..)
	// $datos = array("DatoAtriburto","DatoAtriburto","DatoAtriburto",Etc..)
	$con = BDconex();
	$sql = "INSERT INTO ".$nomTab."(";

	for ($i=0; $i < count($atriTab); $i++) { 
		$sql .= $atriTab[$i];
		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}else{
			$sql .= ") ";
		}
	}

	$sql .= " VALUES(";

	for ($i=0; $i < count($datos); $i++) { 
		$sql .= "'".$datos[$i]."'";
		
		if ($i != count($datos)-1) {
			$sql .= ", ";
		}else{
			$sql .= ") ";
		}
	}
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	if (mysqli_query($con, $sql)) {
		echo '<script language="javascript">alert("Registro creado correctamente");</script>';
		mysqli_close($con);
		return true;
	} else {
		$test = mysqli_error($con);
		echo '<script language="javascript">alert("'.$test.'");</script>';
		mysqli_close($con);
		echo '<script language="javascript">history.back();</script>';//dejar datos en formulario (opcional) 
		return false;
	}
}


		///Instert de productos y fotos  


function InsertProd($nomTabP,$atriTabP,$datosP){
	// $nomTabP = "nombreTablaProducto"
	// $atriTabP = array("AtributoTabla","AtributoTabla","AtributoTabla",Etc..)
	// $datos = array("DatoAtriburto","DatoAtriburto","DatoAtriburto",Etc..)
	$con = BDconex();
	$sql = "INSERT INTO ".$nomTabP."(";

	for ($i=0; $i < count($atriTabP); $i++) { 
		$sql .= $atriTabP[$i];
		if ($i != count($atriTabP)-1) {
			$sql .= ", ";
		}else{
			$sql .= ") ";
		}
	}

	$sql .= " VALUES(";

	for ($i=0; $i < count($datosP); $i++) { 
		$sql .= "'".$datosP[$i]."'";
		
		if ($i != count($datosP)-1) {
			$sql .= ", ";
		}else{
			$sql .= ") ";
		}
	}
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	if (mysqli_query($con, $sql)) {
		echo '<script language="javascript">alert("Registro creado correctamente");</script>';
		mysqli_close($con);
		return true;
	} else {
		$test = mysqli_error($con);
		echo '<script language="javascript">alert("'.$test.'");</script>';
		mysqli_close($con);
		echo '<script language="javascript">history.back();</script>';//dejar datos en formulario (opcional) 
		return false;
	}
}




		///Fin instert de productos y fotos  


function Select($nomTab,$atriTab){
	// $nomTab = "nombreTabla"
	// $atriTab = array("AtributoTabla1","AtributoTabla2","AtributoTabla3",Etc..)
	$con = BDconex();
	$sql = "SELECT ";

	for ($i=0; $i < count($atriTab); $i++) { 
		$sql .= $atriTab[$i];
		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " FROM ".$nomTab;
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	
	$result = mysqli_query($con, $sql);
	$datos[0][0]=null;
	if (mysqli_num_rows($result) > 0) {
		$x = 0;
		while($row = mysqli_fetch_assoc($result)) {
			for ($i=0; $i <count($atriTab) ; $i++) { 
				$datos[$x][$i] = $row[$atriTab[$i]];
			}
			$x++;
		}
	}
	mysqli_close($con);
	return $datos;
	// Retorna un array bidimensional $array[$i][$x]
}

function SelectLimit($nomTab,$atriTab,$numInicio,$numIntervalo){
	// $nomTab = "nombreTabla"
	// $atriTab = array("AtributoTabla1","AtributoTabla2","AtributoTabla3",Etc..)
	// $numInicio = numeroinicial
	// $numIntervalo = cantidadAMostrar
	$con = BDconex();
	$sql = "SELECT ";

	for ($i=0; $i < count($atriTab); $i++) { 
		$sql .= $atriTab[$i];
		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " FROM ".$nomTab." LIMIT ".$numInicio.", ".$numIntervalo."";
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	$result = mysqli_query($con, $sql);
	$datos[0][0]=null;
	if (mysqli_num_rows($result) > 0) {
		$x = 0;
		while($row = mysqli_fetch_assoc($result)) {
			for ($i=0; $i <count($atriTab) ; $i++) { 
				$datos[$x][$i] = $row[$atriTab[$i]];
			}
			$x++;
		}
	}
	mysqli_close($con);
	return $datos;
	// Retorna un array bidimensional $array[$i][$x]
}


function SelectEquals($nomTab,$atriTab,$atriBusc,$param){
	// $nomTab = "nombreTabla"
	// $atriTab = array("AtributoTabla1","AtributoTabla2","AtributoTabla3",Etc..)
	// $atriBusc = " WHERE ..." array("AtributoBuscado1","AtributoBuscado2","AtributoBuscado3",Etc..)
	// $param = " = ...    " array("Parametro1","Parametro1","Parametro1",Etc..)
	$con = BDconex();
	$sql = "SELECT ";

	for ($i=0; $i < count($atriTab); $i++) { 
		$sql .= $atriTab[$i];
		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " FROM ".$nomTab." WHERE ";

	for ($i=0; $i < count($atriBusc); $i++) { 
		$sql .= $atriBusc[$i]." = '".$param[$i]."'";
		if ($i != count($atriBusc)-1) {
			$sql .= " AND ";
		}
	}
	//echo '<script language="javascript">alert("'.$sql.'");</script>';

	$result = mysqli_query($con, $sql);
	$datos[0][0]=null;
	if (mysqli_num_rows($result) > 0) {
		$x = 0;
		while($row = mysqli_fetch_assoc($result)) {
			for ($i=0; $i <count($atriTab) ; $i++) { 
				$datos[$x][$i] = $row[$atriTab[$i]];
			}
			$x++;
		}
	}
	mysqli_close($con);
	return $datos;
	// Retorna un array bidimensional $array[$i][$x]
}

function Update($nomTab,$atriTab,$datosNew){
	// $nomTab = "nombreTabla"
	// $atriTab = array("AtributoTabla","AtributoTabla","AtributoTabla",Etc..)(ES NECESARIO QUE LOS PRIMEROS DATOS SEAN DE LA ID)
	// $datosNew = array("DatoAtriburto","DatoAtriburto","DatoAtriburto",Etc..)(ES NECESARIO QUE LOS PRIMEROS DATOS SEAN DE LA ID)
	$con = BDconex();
	$sql = "UPDATE ".$nomTab." SET ";

	for ($i=1; $i < count($atriTab); $i++) {
		$sql .= $atriTab[$i]." = '".$datosNew[$i]."'";

		if ($i != count($atriTab)-1) {
			$sql .= ", ";
		}
	}
	$sql .= " WHERE ".$atriTab[0]." = '".$datosNew[0]."'";
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	if (mysqli_query($con, $sql)) {
		echo '<script language="javascript">alert("Registro modificado correctamente");</script>';
		mysqli_close($con);
		return true;
	} else {
		$test = mysqli_error($con);
		echo '<script language="javascript">alert("'.$test.'");</script>';
		mysqli_close($con);
		return false;	
	}

	// Retorna un boolean
}

function Delete($nomTab,$atriTab,$parametro){
	// $nomTab = "nombreTabla"
	// $atriTab = "atributoTabla"
	// $parametro = "El donde"
	$con = BDconex();
	$sql = "DELETE FROM ".$nomTab." WHERE ".$atriTab." = '".$parametro."'";

	if (mysqli_query($con, $sql)) {
		echo '<script language="javascript">alert("Registro eliminado correctamente");</script>';
		mysqli_close($con);
		return true;
	} else {
		$test = mysqli_error($con);
		echo '<script language="javascript">alert("'.$test.'");</script>';
		mysqli_close($con);
		return false;
	}

	// Retorna un boolean
}

function SelectCount($nomTab,$atriTab){
	// $nomTab = "nombreTabla"
	// $atriTab = "atributoTabla"
	$con = BDconex();
	$sql = "SELECT COUNT(".$atriTab.") FROM ".$nomTab;
	$result = mysqli_query($con,$sql);
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	$data = mysqli_fetch_assoc($result);
	return $data['COUNT('.$atriTab.')'];
}

function SelectCountEquals($nomTab,$atriTab,$atriBusc,$param){
	// $nomTab = "nombreTabla"
	// $atriTab = "atributoTabla"
	// $atriBusc = " WHERE ..." array("AtributoBuscado1","AtributoBuscado2","AtributoBuscado3",Etc..)
	// $param = " = ...    " array("Parametro1","Parametro1","Parametro1",Etc..)
	$con = BDconex();
	$sql = "SELECT COUNT(".$atriTab.") FROM ".$nomTab." WHERE ";

	for ($i=0; $i < count($atriBusc); $i++) { 
		$sql .= $atriBusc[$i]." = '".$param[$i]."'";
		if ($i != count($atriBusc)-1) {
			$sql .= " AND ";
		}
	}

	$result = mysqli_query($con,$sql);
	//echo '<script language="javascript">alert("'.$sql.'");</script>';
	$data = mysqli_fetch_assoc($result);
	return $data['COUNT('.$atriTab.')'];
	
}


function maxPaginas($cant,$inte){
	// $cant = cantidadDatos
	// $inte = cantidadDatosAMostrar
	while ($cant%$inte!=0) {
		$cant++;
	}
	return $cant/$inte;
	// retorna el numero de pagina mas grande
}

function paginacion($max,$destinoPOST){
	?>
	<form action="<?php echo $destinoPOST; ?>" method="get">
		<table>
			<tr>
				<?php  
				for ($i=1; $i <=$max ; $i++) { 
					?><td><input type="submit" name="pag" value="<?php echo $i; ?>"></td><?php
				}
				?>
			</tr>
		</table>
	</form>
	<?php
}

function paginacionColTip($max,$destinoPOST,$stringX){//solo apto COLOR O TIPO
	?>
	<form action="<?php echo $destinoPOST; ?>" method="get">
		<input type="hidden" name="<?php echo $stringX; ?>" value="JAja">
		<table>
			<tr>
				<?php  
				if ($max>1) {
					for ($i=1; $i <=$max ; $i++) { 
						?><td><input type="submit" name="pag" value="<?php echo $i; ?>"></td><?php
					}
				}
				?>
			</tr>
		</table>
	</form>
	<?php
}
?>