<?php 
include 'crud.php'; 
if ($_POST['btnColtip']=="Agregar") {


	if ($_POST['colTip']=="colores") {
		$atributos = array('NOM_COL');
		$btn="btn1";
	}elseif($_POST['colTip']=="tipos"){
		$atributos = array('NOM_TIP');
		$btn="btn2";
	}
	
	$datos = array(ucfirst(strtolower($_POST['nom'])));

	if (Insert($_POST['colTip'],$atributos,$datos)) {
		?>
		<form action="../ingresoColTip.php" name="vol" method="post">
			<input type="hidden" name="<?php echo $btn; ?>" value="set">
		</form>
		<?php
		echo '<script language="javascript">document.vol.submit()</script>';
	}

}elseif ($_POST['btnColtip']=="Modificar") {

	if ($_POST['colTip']=="colores") {
		$atributos = array('ID_COL','NOM_COL');
		$btn="btn1";
	}elseif($_POST['colTip']=="tipos"){
		$atributos = array('ID_TIP','NOM_TIP');
		$btn="btn2";
	}
	
	$datos = array($_POST['idList'],ucfirst(strtolower($_POST['nom'])));

	if (Update($_POST['colTip'],$atributos,$datos)) {
		?>
		<form action="../ingresoColTip.php" name="vol" method="post">
			<input type="hidden" name="<?php echo $btn; ?>" value="set">
		</form>
		<?php
		echo '<script language="javascript">document.vol.submit()</script>';
	}else{
		?>
		<form action="../ActualizarColTip.php" name="vol" method="post">
			<input type="hidden" name="colTip" value="<?php echo $_POST['colTip']; ?>">
			<input type="hidden" name="idList" value="<?php echo $_POST['idList']; ?>">
			<input type="hidden" name="nomList" value="<?php echo $_POST['nomList']; ?>">
			<input type="hidden" name="btnList" value="Editar">
		</form>
		<?php
		echo '<script language="javascript">document.vol.submit()</script>';
	}

	
}elseif($_POST['btnColtip']=="Eliminar"){
	if ($_POST['colTip']=="colores") {
		$atributo = 'ID_COL';
		$btn="btn1";
	}elseif($_POST['colTip']=="tipos"){
		$atributo = 'ID_TIP';
		$btn="btn2";
	}

	if (Delete($_POST['colTip'],$atributo,$_POST['idList'])) {
		?>
		<form action="../ingresoColTip.php" name="vol" method="post">
			<input type="hidden" name="<?php echo $btn; ?>" value="set">
		</form>
		<?php
		echo '<script language="javascript">document.vol.submit()</script>';
	}else{
		?>
		<form action="../ingresoColTip.php" name="vol" method="post">
			<input type="hidden" name="<?php echo $btn; ?>" value="set">
		</form>
		<?php
		echo '<script language="javascript">document.vol.submit()</script>';
	}
}
?>