<table border="1">
	<tr>
		<th colspan="2">Modicar <?php echo $_POST['colTip']; ?> de productos</th>
	</tr>
	<tr>
		<td>
			<label for="nom"><?php echo $_POST['colTip2']; ?>:</label>
		</td>
		<td>
			<input type="text" name="nom" maxlength="25" required="true" value="<?php echo $_POST['nomList']; ?>">
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<input type="hidden" name="colTip" value="<?php echo $_POST['colTip']; ?>">
			<input type="hidden" name="idList" value="<?php echo $_POST['idList']; ?>">
			<input type="submit" name="btnColtip" value="Modificar">
			<input type="button" value="Vaciar" onclick="javascript:location.reload()">
			<input type="button" value="Volver atras" onclick="history.back();">
		</td>
	</tr>
</table>