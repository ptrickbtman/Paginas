<table border="1">
	<tr>
		<th colspan="2">Ingreso de <?php echo $X; ?> de productos</th>
	</tr>
	<tr>
		<td>
			<label for="nom"><?php echo $x; ?>:</label>
		</td>
		<td>
			<input type="text" name="nom" maxlength="25" required="true">
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<input type="hidden" name="colTip" value="<?php echo $X; ?>">
			<input type="submit" name="btnColtip" value="Agregar">
			<input type="button" value="Vaciar" onclick="javascript:location.reload()">
			<input type="button" value="Volver a menu" onclick="location.href='index.php';">
		</td>
	</tr>
</table>