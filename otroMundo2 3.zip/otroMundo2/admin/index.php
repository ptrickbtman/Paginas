<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">

	<title>Administrador</title>


</head>
<style>
	.contBtnAd{
		width: 100%;
	}
</style>
<body>
	<?php 
	//temporal
	?>
	<div class="contBtnAd">
		<form action="ingresoColTip.php" method="post">
			<input type="submit" name="btn1" value="Gestionar colores de productos"><br>
			<input type="submit" name="btn2" value="Gestionar tipos de productos">
		</form>
		<input type="button" name="btn" value="Gestionar productos" onclick="location.href='ingresoProductos.php';"><br>
		<input type="button" name="btn" value="Volver" onclick="location.href='../';">
	</div>
</body>
</html>