$(document).ready(function(){

  $(function() {
    $('#fi0').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis0').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis0').attr("src",result);
    }
  });

  $(function() {
    $('#fi1').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis1').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis1').attr("src",result);
    }
  });  

  $(function() {
    $('#fi2').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis2').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis2').attr("src",result);
    }

  });

  $(function() {
    $('#fi3').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis3').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis3').attr("src",result);
    }
  });

  $(function() {
    $('#fi4').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis4').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis4').attr("src",result);
    }
  });  

  $(function() {
    $('#fi5').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis5').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis5').attr("src",result);
    }

  });

  $(function() {
    $('#fi6').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis6').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis6').attr("src",result);
    }

  });

  $(function() {
    $('#fi7').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis7').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis7').attr("src",result);
    }
  });

  $(function() {
    $('#fi8').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis8').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis8').attr("src",result);
    }
  });  

  $(function() {
    $('#fi9').change(function(e) {
      addImage(e); 
    });

    function addImage(e){
      var file = e.target.files[0],
      imageType = /image.*/;

      if (!file.type.match(imageType)){
        $('#vis9').attr("src","img/default.png");
        return;
      }

      var reader = new FileReader();
      reader.onload = fileOnload;
      reader.readAsDataURL(file);
    }

    function fileOnload(e) {
      var result=e.target.result;
      $('#vis9').attr("src",result);
    }

  });
});