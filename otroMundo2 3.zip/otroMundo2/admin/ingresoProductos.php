<?php 
include 'controladores/crud.php'
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title></title>
	<script src="js/jquery.js"></script>
	<script src="js/preVis.js"></script>
</head>
<style>
	.contFotos{
		width: 200px;
		height: 180px;
		margin: 10px auto 0px auto;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	input[type="file"]{
		width: 135px;
		margin-top: 5px; 
	}
	.tdFotos{
		overflow-y: scroll;
		text-align: center;
	}
	.divFiles{
		height: 500px;
		width: 210px;
	}
	.visFotos{
		max-width: 100%;
		max-height: 100%;
	}
</style>
<body>
	<div class="contIngreso">
		<div class="contForm">
			<form action="controladores/crudProd.php" method="POST" enctype="multipart/form-data">
				<?php include "vistas/productos.php" ?>
			</form>
		</div>
	</div>
</body>
</html>